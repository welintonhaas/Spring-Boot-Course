package io.github.secutiry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecutiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
